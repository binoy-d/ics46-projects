#include "proj5.hpp"


int main()
{
	return 0;
}
